function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(220);
  background('random'); }
 function draw() {
    // função que faz com que mude a cor
   if (mouseIsPressed) {
   fill('blue');
 } else {
   fill(255);
 }  
   // codigo que faz o formato
   square(mouseX, mouseY, 90, 30)

 }